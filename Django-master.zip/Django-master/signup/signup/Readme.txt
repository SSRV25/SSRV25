i would recommend to use code from this project instead of downloading it because some of the files from django db are not added by me. You can freely copy and paste this project methods.
