from django.apps import AppConfig


class ChatappConfig(AppConfig):
    name = 'chatapp'
