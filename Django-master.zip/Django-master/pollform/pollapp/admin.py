from django.contrib import admin
from .models import PollQuestions

admin.site.register(PollQuestions)
