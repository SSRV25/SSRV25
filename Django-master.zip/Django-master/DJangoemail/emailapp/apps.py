from django.apps import AppConfig


class EmailappConfig(AppConfig):
    name = 'emailapp'
