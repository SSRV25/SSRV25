from django.contrib import admin
from .models import PostData

admin.site.register(PostData)
